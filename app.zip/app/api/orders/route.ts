import { NextRequest, NextResponse } from "next/server";
import WooCommerce from "@/lib/woocommerce";

export async function GET(req: NextRequest) {
  try {
    const email = req.nextUrl.searchParams.get("email");

    if (!email) {
      return NextResponse.json({
        success: false,
        message: "Email is required.",
      });
    }

    // Find the WooCommerce customer
    const customerResponse = await WooCommerce.get("customers", {
      email,
    });

    const customer = customerResponse.data[0];

    if (!customer) {
      return NextResponse.json({
        success: true,
        orders: [],
      });
    }

    // Get orders for this customer
    const ordersResponse = await WooCommerce.get("orders", {
      customer: customer.id,
      per_page: 100,
    });

    return NextResponse.json({
      success: true,
      orders: ordersResponse.data,
    });

  } catch (error: any) {
    console.error(error);

    return NextResponse.json({
      success: false,
      message: error.message,
    });
  }
}